Title

Restaurant Analysis

Description

This workbook has data visualizations and insights that show what restaurants are popular and why.

Workbook Link

https://public.tableau.com/views/RestuarantAnaylsis/TopandBottomRestuarants?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

How to use

Top Restaurants Filter

Click directly on any restaurant column in the Top & Bottom Restaurant bar chart to filter all visuals and view detailed insights for that specific restaurant.

Toggle between Top 10 and Bottom 10 using the dropdown above the chart to explore performance variations.

Quarterly Filter

Select a specific quarter to view sales, orders, and customer behavior over time.

All visualizations update to reflect data from the chosen quarter.

Customer Monthly Income Filter

Analyze restaurant performance across different income brackets.

Useful for understanding spending habits of low, mid, and high-income users.

Rating Filter

Filter results by average restaurant rating.

Helps identify which highly-rated restaurants are also top performers.

Contant Info

werkukaleb789@gmail.com

 
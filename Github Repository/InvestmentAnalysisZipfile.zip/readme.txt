# Neighborhood Revenue & Property Size Analysis

## 📊 Project Overview

This project analyzes property listings in various New York City neighborhoods to uncover high-demand areas, popular property sizes, and revenue performance. The goal is to help stakeholders make informed decisions on property investment, pricing strategies, and market targeting.

---

## 📋 Executive Summary

- 🔟 **Top 10 neighborhoods** by demand: Lower East Side, Hells Kitchen, Harlem, Midtown, Upper West Side, Chelsea, East Village, East Harlem, West Village, Upper East Side.
- 🏘️ **1-bedroom properties** are the most popular in all neighborhoods except Midtown, where studios are preferred.
- 💰 **Average annual revenue**: $65,105.42  
- 💎 **Maximum annual revenue**: $359,280.00  
- ⚠️ **Minimum annual revenue**: $0.00  
- 📉 **Median annual revenue**: $60,774.00  
- ✅ **Recommendation**: Invest in the top 10 neighborhoods using the most popular property size to maximize booking frequency and revenue.

---

## 📁 Table of Contents

- Assumptions and Change Logs  
- Data Dictionary  
- Raw Listings & Calendar  
- Clean Listings & Calendar  
- Popular Neighborhoods  
- Attractive Property Sizes  
- Best Property Size per Neighborhood  
- Revenue Ranking (Top Revenue)

---

## 🧠 Assumptions

- **Review Count as Proxy for Demand**: Listings with more reviews are considered more frequently booked.
- **Bedroom Count as Popularity Indicator**: The most reviewed property size is considered the most popular.
- **Revenue Calculation**: If `available = FALSE`, revenue = adjusted price; otherwise, revenue = $0.
- **Annual Revenue Projection**: 30-day revenue × 12 assumes consistent monthly performance.
- **Top Listings Filtering**: Only listings from the top 10 neighborhoods using the most popular property size are analyzed for revenue ranking.

---

## 🔧 Methodology

1. **Data Cleaning**
   - Created `clean_listings` and `clean_calendar` tabs by trimming text, normalizing categories, and removing duplicates.
   - Replaced ambiguous entries (e.g., `t`, `f`) with `TRUE`, `FALSE`.

2. **Feature Engineering**
   - Created columns like `clean_neighborhood`, `clean_bedroom`, and `revenue_earned`.
   - Used `IF`, `TRIM`, `PROPER`, and conditional logic formulas to clean and standardize data.

3. **Analysis**
   - Used pivot tables to:
     - Count listings per neighborhood and bedroom size.
     - Identify the most common property size per neighborhood.
     - Sum total reviews and estimated annual revenue.
   - Created bar charts, heatmaps, and conditional formatting for visual insight.

---

## 📈 Key Visuals

- **Top 10 Neighborhoods by Total Reviews**  
  Highlights high-demand areas.

- **Popular Property Sizes**  
  1-bedroom and 2-bedroom units dominate.

- **Heatmap of Property Size Preferences by Neighborhood**  
  Shows varying popularity of bedroom counts across neighborhoods.

- **Bar Chart of Best Property Sizes by Neighborhood**  
  Displays which bedroom sizes perform best by area.

- **Revenue Distribution Stats**  
  Offers insight into earning potential per listing.

---

## 🧰 Tools Used

- **Google Sheets**
  - Pivot Tables
  - Conditional Formatting
  - IF, DATEDIF, TRIM, PROPER, COUNTIF
  - Bar Charts & Heatmaps

---

## 👤 Author

**Kaleb Werku**  
📧 [kalebwerku3@gmail.com](mailto:kalebwerku3@gmail.com)
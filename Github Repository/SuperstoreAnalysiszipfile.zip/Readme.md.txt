Title

Kaleb's Sprint 4 Project

Description

This workbook has data visualizations and insights to help the efficiency and profitability of Super Store.

Data Source

https://practicum-content.s3.us-west-1.amazonaws.com/data-eng/BIA/Dataset/Superstore.xls

Tablue Workbook Link

https://public.tableau.com/views/SuperstoreAnalysis_17514046809790/ProfittoReturnRate?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

How to Use

In the Sub-Category and Region Profitability sheet there is a filter that shows you the Top 5 and Bottom 5 Combination of Sub-Category and Region Profits.

In the Best Combination sheet there is a scatter plot with State in rows and discrete months in columns with average profit as the value. I ranked the cells in descending order with average profit. After I created a filter called "Top N Avg Profit" where whatever number you chose it will show you the top n cells for average profit. 

Contact info

Email Werkukaleb789@gmail.com
 
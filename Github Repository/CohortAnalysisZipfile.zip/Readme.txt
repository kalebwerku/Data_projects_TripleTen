# User Cohort and Conversion Funnel Analysis

## Description

This project provides a comprehensive analysis of user behavior through two key frameworks: a **conversion funnel** and **cohort retention analysis**. The goal is to understand how users interact with a product from viewing to purchasing and evaluate how well the business retains its customers over time. The analysis was performed using Google Sheets with pivot tables, formulas, and cohort-based segmentation.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Key Findings](#key-findings)
- [Data Sources](#data-sources)
- [Methodology](#methodology)
  - [Conversion Funnel](#conversion-funnel)
  - [Cohort Retention Analysis](#cohort-retention-analysis)
- [Tools Used](#tools-used)
- [Author](#author)
- [License](#license)

---

## Project Overview

The project explores user behavior using event-level data that tracks user interaction with an e-commerce platform. The funnel includes stages from product views to shopping cart actions and final purchases. In parallel, a cohort analysis was performed to identify customer retention trends over time, segmented by first purchase month and cohort age.

Project Link - https://docs.google.com/spreadsheets/d/19A_rV-0WkDWEsVreckEdB0uH1Lh2_x93Kw5vfmM7REg/edit?usp=sharing
---

## Key Findings

- **Conversion Funnel**: Approximately **10%** of users who view a product ultimately complete a purchase.
- **Shopping Cart Drop-off**: 29% of users who view products add them to a cart, but only a subset continue to purchase.
- **Retention Trends**: Retention rates decline with each cohort until **January 2021**, where an upward trend begins.

---

## Data Sources

The analysis is based on a raw dataset containing the following columns:

- `user_id`
- `event_type` (e.g., view, shopping_cart, purchase)
- `event_date`
- `category_type`, `brand`, and `price` (used for reference)

---

## Methodology

### Conversion Funnel

1. A pivot table was used to count the number of unique users per `event_type`.
2. Conversion rates were calculated from:
   - Views → Shopping Cart
   - Shopping Cart → Purchase
   - Views → Purchase
3. Resulting insights showed significant drop-offs at each stage of the funnel.

#### Funnel Stats Example:

| Event Type     | Unique Users | Conversion Rate |
|----------------|--------------|-----------------|
| View           | 10,453       | 100%            |
| Shopping Cart  | 3,036        | 29%             |
| Purchase       | 1,081        | 10%             |

---

### Cohort Retention Analysis

1. A new sheet (`purchase_activity`) was created to calculate the **first purchase date** for each user.
2. A cohort matrix was created using:
   - `first_order_month`: User’s first purchase month.
   - `cohort_age`: Number of months since the first purchase.
3. Retention was measured using unique user counts and percentages over time.

#### Retention Table Example (Percentages):

| Cohort Month | M+1   | M+2   | M+3   | M+4   |
|--------------|-------|-------|-------|-------|
| 2020-09      | 12.5% | 6.25% | 0%    | 3.13% |
| 2020-10      | 7.49% | 3.74% | 0.53% | 0.53% |
| 2021-01      | 6.87% | 0%    | 0%    | 0%    |

---

## Tools Used

- **Google Sheets**
- **Pivot Tables**
- **DATEDIF Function**
- **COUNTUNIQUE**
- **Vlookup**

---

## Author

**Kaleb Werku**  
📧 [kalebwerku3@gmail.com](mailto:kalebwerku3@gmail.com)